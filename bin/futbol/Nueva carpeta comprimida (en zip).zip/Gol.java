package futbol;

public interface Gol {
    String equipoMarcador();
    String jugador();
    int minuto();
    Partido partido();
}
