package futbol;

public interface Partido {
    String equipoLocal();
    String equipoVisitante();
    int jornada();
}
