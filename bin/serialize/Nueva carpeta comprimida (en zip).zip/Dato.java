package serialize;

import java.io.Serializable;

public interface Dato extends Serializable{
    public String getNombre();
}
