package serialize;

public interface DatoTexto extends Dato{
    public String getValor();
}
