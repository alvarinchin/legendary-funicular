/**
 * 
 */
package banco;

/**
 * @author alvaro
 *
 */
public class TarjetaDeCredito extends ProductoBancario {

	/**
	 * @param titular
	 * @param codigo
	 */
	public TarjetaDeCredito(String titular, int codigo) {
		super(titular, codigo);
		
	}
	@Override
	public void movimientoSaldo(double movimiento) {
		if (movimiento >=0) {
			throw new IllegalArgumentException("El movimiento en tarjeta no puede ser positivo");
		}
		super.movimientoSaldo(movimiento);
	}

}
